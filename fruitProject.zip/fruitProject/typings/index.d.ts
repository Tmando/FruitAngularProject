/// <reference path="globals/firebase/index.d.ts" />
